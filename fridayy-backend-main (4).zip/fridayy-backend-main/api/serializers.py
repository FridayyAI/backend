from rest_framework import serializers
from .models import FridayUser, Category, store, products, Catelog

class FridayUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = FridayUser
        fields = ['first_name', 'last_name', 'phone_no', 'email', 'password', 'is_google_login']
        extra_kwargs = {
            'password': {'write_only': True},  # Ensure password is write-only
        }

    def create(self, validated_data):
        
        user = FridayUser.objects.create_user(**validated_data)
        user.set_password(validated_data['password'])
        user.save()
        return user


class CatelogSerializer(serializers.ModelSerializer):
    class Meta:
        model = Catelog
        fields = '__all__'

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = products
        fields = (
            'id',
            'user_id',
            'store_id',
            'catalog_id',
            'product_name',
            'product_image',
            'ai_image',
            'product_price',
            'discounted_price',
            'product_description',
            'image_type',
            'img_order',
        )

    def create(self, validated_data):
        return products.objects.create(**validated_data)


class StoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = store
        fields = ('id', 'user_id', 'logo', 'about_store', 'name', 'category','store_address_line_1','store_address_line_2','whatsapp_number','phone_number')

    def create(self, validated_data):
        return store.objects.create(**validated_data)
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'
