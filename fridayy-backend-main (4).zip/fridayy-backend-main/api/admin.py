# from django.contrib import admin

# # Register your models here.
# from .models import FridayUser, Category, Store, Product, Catelog

# admin.site.register(FridayUser)
# admin.site.register(Catelog)
# admin.site.register(Product)
# admin.site.register(Store)
# admin.site.register(Category)

