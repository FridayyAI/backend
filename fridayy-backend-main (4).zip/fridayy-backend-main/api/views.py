from django.shortcuts import render, get_object_or_404
from rest_framework import generics
from .serializers import FridayUserSerializer, CategorySerializer, StoreSerializer, ProductSerializer, CatelogSerializer,CategorySerializer
from .models import FridayUser, Category, store, products, Catelog
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import SessionAuthentication, TokenAuthentication
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.authtoken.models import Token
from django.db import transaction

@api_view(['GET', 'POST', 'PUT', 'DELETE'])
def home(request):
    return Response({'message': 'Api/'})

@api_view(['GET'])
def get_user(request):
    print(request.user)
    user = get_object_or_404(FridayUser, id=request.user_id)
    serializer = FridayUserSerializer(user)
    return Response(serializer.data)

@api_view(['POST'])
def google_login(request):
    try:  
        email = request.data.get('email')
        user = FridayUser.objects.filter(email=email).first() 
        if user:
            user = get_object_or_404(FridayUser, email=request.data['email'])
            
            if user.is_google_login == True:
                token, created = Token.objects.get_or_create(user=user)
                serializer = FridayUserSerializer(user)
                return Response({'token': token.key, 'user': serializer.data})
            else:
                return Response("Invalid credentials", status=status.HTTP_400_BAD_REQUEST)
        else:
            data = request.data.copy()
            data['is_google_login'] = True
            serializer = FridayUserSerializer(data=data)
            if serializer.is_valid():
                with transaction.atomic():  # Ensure atomic transaction
                    user = serializer.save()  # Save the user to the database
                    user.set_password(request.data['password'])
                    user.save()  # Save the user again after setting the password
                    token, created = Token.objects.get_or_create(user=user)
                    return Response({'token': token.key, 'user': serializer.data}, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def login(request):
    try:
        user = get_object_or_404(FridayUser, email=request.data['email'])
        if user.check_password(request.data['password']):
            token, created = Token.objects.get_or_create(user=user)
            serializer = FridayUserSerializer(user)
            return Response({'token': token.key, 'user': serializer.data})
        else:
            return Response("Invalid credentials", status=status.HTTP_400_BAD_REQUEST)
    except:
        return Response("User not found", status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
@authentication_classes([SessionAuthentication, TokenAuthentication])
@permission_classes([IsAuthenticated])
def test_token(request):
    return Response("passed!")

@api_view(['POST', 'GET'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
def logout(request):
    try:
        token_key = request.headers.get('Authorization').split(' ')[1]
        token = Token.objects.get(key=token_key)
        token.delete()
        return Response("Logout successful", status=status.HTTP_200_OK)
    except Token.DoesNotExist:
        return Response("Invalid token", status=status.HTTP_401_UNAUTHORIZED)
    
@api_view(['POST'])
def register(request):
    print(request.data)
    data = request.data.copy()
    data['is_google_login'] = False
    serializer = FridayUserSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        user.set_password(request.data['password'])
        user.save()
        token, created = Token.objects.get_or_create(user=user)
        return Response({'token': token.key, 'user': serializer.data}, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#========================================================================================================================

# class StoreCreate(generics.ListCreateAPIView):
#     print("StoreCreate")
#     serializer_class = StoreSerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         user = self.request.user
#         return store.objects.filter(user_id=user)

#     def perform_create(self, serializer):
#         if serializer.is_valid():
#             serializer.save(user_id=self.request.user)
#         else:
#             print(serializer.errors)
    
# class StoreDelete(generics.DestroyAPIView):
#     serializer_class = StoreSerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         user = self.request.user
#         return Store.objects.filter(user_id=user)
    
# class StoreUpdate(generics.UpdateAPIView):
#     serializer_class = StoreSerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         user = self.request.user
#         return Store.objects.filter(user_id=user)

#     def perform_update(self, serializer):
#         if serializer.is_valid():
#             serializer.save(user_id=self.request.user)
#         else:
#             print(serializer.errors)
            
# #--------------------------------------------------------------

# class ProductCreate(generics.ListCreateAPIView):
#     serializer_class = ProductSerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         user = self.request.user
#         shop = self.request.GET.get('shop', None)
#         return Product.objects.filter(shop_id=shop)

#     def perform_create(self, serializer):
#         if serializer.is_valid():
#             serializer.save(shop_id=self.request.GET.get('shop', None), user_id=self.request.user)
#         else:
#             print(serializer.errors)


# class ProductDelete(generics.DestroyAPIView):
#     serializer_class = ProductSerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         user = self.request.user
#         return Product.objects.filter(user_id=user)
# class ProductUpdate(generics.UpdateAPIView):
#     serializer_class = StoreSerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         user = self.request.user
#         return Store.objects.filter(user_id=user)

#     def perform_update(self, serializer):
#         if serializer.is_valid():
#             serializer.save(user_id=self.request.user)
#         else:
#             print(serializer.errors)
            
#  #--------------------------------------------------------------           
# class CategoryCreate(generics.ListCreateAPIView):
#     serializer_class = CategorySerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         return Category.objects.all()

#     def perform_create(self, serializer):
#         if serializer.is_valid():
#             serializer.save()
#         else:
#             print(serializer.errors)


# class CategoryDelete(generics.DestroyAPIView):
#     serializer_class = CategorySerializer
#     authentication_classes = [TokenAuthentication]
#     permission_classes = [IsAuthenticated]

#     def get_queryset(self):
#         return Category.objects.all()






#========================================================================================================================
# Create your views here.

#Abhishek

# Create your views here.

from .forms import ImageForm

# views.py
from django.shortcuts import render, redirect
from .forms import ImageForm
from .models import UploadedImage
from django.http import JsonResponse
from contentful import Client
from django import template
from django.views.decorators.csrf import csrf_exempt
from PIL import Image, ImageOps
import requests
from io import BytesIO
from decouple import config
from .models import products
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.authentication import SessionAuthentication, TokenAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from .serializers import ProductSerializer  # Assuming you have a serializer for Product
from .models import store
from .serializers import StoreSerializer

from openai import OpenAI
import json
import requests
import time
import requests
from bs4 import BeautifulSoup
import boto3
from django.conf import settings
from botocore.exceptions import NoCredentialsError
from .models import UpdatedHTML 
import requests


client = Client('v4776asqgjtj', 'W0zMEEtQukZm7fBbawymdxQCiLkLGjYtBHTtqQVyrZw')
import json

@api_view(['GET'])
def get_template(request):

    if request.method == 'GET':
        category = request.GET.get('category', None)
        if category:
            content_type_id = 'productCatalogs'

            entries = client.entries({
                'content_type': content_type_id,
                'select': 'fields',  
                'limit': 1000 
            })

            category_templates = []

            for entry in entries:
                entry_category = entry.fields().get('category')
                url = entry.fields().get('catalog_template_url')
                title = entry.fields().get('title')
                k = entry.fields().get('catalog_thumbnail')
                thumbnail = "https:" + str(k).split(' ')[-1].strip("'")[5:-2]
                num = entry.fields().get('imgnumber')
                id=entry.fields().get('templateid')
                type=entry.fields().get('image_type')
                if entry_category == category and url:
                    template_data = {
                                'name': title,
                                'url': url,
                                'thumbnail': thumbnail,
                                'total_images': num,
                                'catalog_id': id,
                                'image_type': type  # Assuming type is a single string, if not, you can wrap it in a list
                            }
                            
                    category_templates.append(template_data)
                    


            # Optionally, you can render a template with the fetched data
            return JsonResponse({'category_templates': category_templates})
        else:
            return JsonResponse({'error': 'Category not provided'}, status=400)
    else:
        return JsonResponse({'error': 'Only GET method allowed'}, status=405)


api_obj = config('api_obj')

API_URL = "https://api-inference.huggingface.co/models/Salesforce/blip-image-captioning-large"
headers = {"Authorization": "Bearer "+api_obj}


def query_image_caption(image):
    print("query",image)
    response = requests.post(API_URL, headers=headers, data=image)
    return response.json()

@api_view(['GET'])
def object_detection(request):
    img_url=request.GET.get('img_url', None)
    k=query_image_caption(img_url)
    caption=k[0]['generated_text']
    return JsonResponse({'caption': caption})

api_key = config('API_KEY')
cl = OpenAI(api_key=api_key)


@api_view(['GET'])
def description(request):
    img_keyword=request.GET.get('img_keyword')
    AI_description=generate_desc(img_keyword)
    return JsonResponse({'AI_description': AI_description})

def generate_desc(text: str):
    response = cl.chat.completions.create(
        model="gpt-3.5-turbo", #"gpt-3.5-turbo-0125", #"gpt-3.5-turbo",
        response_format={ "type": "json_object" },
        messages=[
            {
                "role": "system",
                "content": 'Act as an expert social media marketer for an e-commerce brand.'
                        'I will send you a few keywords that describes the product'
                        'Can you create a 2 - 3 line product description emphasizing the key features, benefits, and unique selling points.'
                        'Please create a 2 -3 line description.'
                        'Send the response in the following JSON format - { description: <Description>}'
            },
            {
                "role": "user",
                "content": f"Product: {text}"
            },
        ],
        temperature=1,
        max_tokens=1024,
        )
    try:
        generated_text = response.choices[0].message.content
        data = json.loads(generated_text) # Load the JSON string into a dictionary
        idea = data["description"] # Extract the idea directly return idea
        print(idea)
        return idea
    except Exception as e:
        print(f"An error occurred, probably openai being smart again : {e}")

def generate_text(text: str):
    response = cl.chat.completions.create(
        model="gpt-3.5-turbo", #"gpt-3.5-turbo-0125", #"gpt-3.5-turbo",
        response_format={ "type": "json_object" },
        messages=[
            {
                "role": "system",
                "content": 'Act as an expert social media marketer for an e-commerce brand. '
                        'I will send you the name of the product. Please send 1 background idea, '
                        'that would be relevant and would make the product images more visually attractive '
                        'for product catalogs, Instagram, and other social media networks. '
                        'Please send 1-line ideas. (**Do not add the product in the one-line idea.**) '
                        'Just write only the idea. Please send the result in the following JSON format: '
                        '{"idea": "<your generated idea here>"}'
            },
            {
                "role": "user",
                "content": f"Product: {text}"
            },
        ],
        temperature=1,
        max_tokens=1024,
        )
    try:
        generated_text = response.choices[0].message.content
        data = json.loads(generated_text) # Load the JSON string into a dictionary
        idea = data["idea"] # Extract the idea directly return idea
        print(idea)
        return idea
    except Exception as e:
        print(f"An error occurred, probably openai being smart again : {e}")

def generate_about(text: str):
    response = cl.chat.completions.create(
        model="gpt-3.5-turbo", #"gpt-3.5-turbo-0125", #"gpt-3.5-turbo",
        response_format={ "type": "json_object" },
        messages=[
            {
                "role": "system",
                "content": "I want to create an About us section on my e-commerce product catalog using the keywords"
                            " Please create a 7 - 8 line description using the keywords for the About Us section."
                            "Please send the response in the following JSON format:"
                            "{ description: <description>}"
            },
            {
                "role": "user",
                "content": f"keywords: {text}"
            },
        ],
        temperature=1,
        max_tokens=1024,
        )
    try:
        generated_text = response.choices[0].message.content
        data = json.loads(generated_text) # Load the JSON string into a dictionary
        idea = data["description"] # Extract the idea directly return idea
        print(idea)
        return idea
    except Exception as e:
        print(f"An error occurred, probably openai being smart again : {e}")


@api_view(['POST'])
def upload_img_hero(request):
    uploaded_images = request.FILES.getlist('img0')
    user_id = request.data.get('user_id')
    store_id = request.data.get('store_id')
    image_urls = []
    detection = []
    image_type=0

    s3 = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                      aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)

    for image in uploaded_images:
        file_name = f"{user_id}/{store_id}/{image.name}"
        
        try:
            # Upload image to S3
            s3.upload_fileobj(image, settings.AWS_STORAGE_BUCKET_NAME, file_name)
            image_url = f"https://{settings.AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
            k = query_image_caption(image_url)
            output={'image_url': image_url, 'detection': k[0]['generated_text']}
            image_urls.append(output)
            
        except NoCredentialsError:
            return JsonResponse({'error': 'AWS credentials not available.'}, status=400)

    return JsonResponse({'image_details': image_urls, 'image_type':image_type})

@api_view(['POST'])
def upload_img(request):
    uploaded_images = request.FILES.getlist('img1')
    user_id = request.data.get('user_id')
    store_id = request.data.get('store_id')
    image_urls = []
    detection = []
    image_type=1

    s3 = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                      aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)

    for image in uploaded_images:
        file_name = f"{user_id}/{store_id}/{image.name}"
        
        try:
            # Upload image to S3
            s3.upload_fileobj(image, settings.AWS_STORAGE_BUCKET_NAME, file_name)
            image_url = f"https://{settings.AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
            #image_urls.append(image_url)
            k = query_image_caption(image_url)
            detection.append(k[0]['generated_text'])
            output={'image_url': image_url, 'detection': k[0]['generated_text']}
            image_urls.append(output)
            
        except NoCredentialsError:
            return JsonResponse({'error': 'AWS credentials not available.'}, status=400)

    return JsonResponse({'image_details': image_urls, 'image_type':image_type})


@api_view(['POST'])
def upload_img_about(request):
    uploaded_images = request.FILES.getlist('img2')
    user_id = request.data.get('user_id')
    store_id = request.data.get('store_id')
    image_type=2
    image_urls = []
    detection = []

    s3 = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                      aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)

    for image in uploaded_images:
        file_name = f"{user_id}/{store_id}/{image.name}"
        
        try:
            # Upload image to S3
            s3.upload_fileobj(image, settings.AWS_STORAGE_BUCKET_NAME, file_name)
            image_url = f"https://{settings.AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
            k = query_image_caption(image_url)
            output={'image_url': image_url, 'detection': k[0]['generated_text']}
            image_urls.append(output)
            
        except NoCredentialsError:
            return JsonResponse({'error': 'AWS credentials not available.'}, status=400)

    return JsonResponse({'image_details': image_urls, 'image_type':image_type})




def photai(input_image_link,prompt):
    url = 'https://prodapi.phot.ai/external/api/v2/user_activity/background-generator'
    headers = {
    'x-api-key': '661cd2e68bc855e650b13257_00082d7992f766ad0834_apyhitools',
    'Content-Type': 'application/json'
    }
    data = {
    'file_name': 'FTDUV9D3_2024-03-30T07_16_44.558Z_output_3.jpeg', 
    'input_image_link': input_image_link,
    'prompt': prompt  
    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code == 200:
        print(response.json())
    else:
        print(f"Error: {response.status_code} - {response.text}")

    jsonfile=response.json()
    k=jsonfile['order_id']

    url = f"https://prodapi.phot.ai/external/api/v1/user_activity/order-status?order_id={k}"

    payload={}

    headers = {
    'x-api-key': '661cd2e68bc855e650b13257_00082d7992f766ad0834_apyhitools',
    'Content-Type': 'application/json'
    }
    
    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)
    temp=response.json()
    print(temp)
    order_status_code=temp['order_status_code']
    
    while(order_status_code!=200):
        url = f"https://prodapi.phot.ai/external/api/v1/user_activity/order-status?order_id={k}"
        payload={}

        headers = {
        'x-api-key': '661cd2e68bc855e650b13257_00082d7992f766ad0834_apyhitools',
        'Content-Type': 'application/json'
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        m=response.json()
        order_status_code=m['order_status_code']
        time.sleep(5)
    
    final=response.json()
    output=final['output_urls']
    
    return output

def uncrop_image(img_url,catlog_id,tag):
    content_type_id = 'productCatalogs'
    entries = client.entries({
                'content_type': content_type_id,
                'select': 'fields',  
                'limit': 1000 
            })
    
    url = ""
    for entry in entries:
        id_value = entry.fields().get('templateid')   
        if id_value == catlog_id:
            url = entry.fields().get('catalog_template_url')
            break
    
    dim=get_size(url,tag)
    wid=dim[0]
    hgt=dim[1]
    crop=Image_extender(img_url,wid,hgt)
    return crop


@api_view(['POST'])
def create_product(request):
    if request.method == 'POST':
        serializer = ProductSerializer(data=request.data)
        
        ai_image=request.data.get('ai_image')
        print(ai_image)
        if ai_image==None:
            product_image=request.data.get('product_image')
            catalog_id=request.data.get('catalog_id')
            image_tag=request.data.get('image_type')
            k=uncrop_image(product_image,catalog_id,image_tag)
        
        if serializer.is_valid():
            product_instance=serializer.save()
            if ai_image==None:
                product_instance.product_image = k
                product_instance.save()

            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@api_view(['POST'])
def create_store(request):
    if request.method == 'POST':
        serializer = StoreSerializer(data=request.data)
        
        if serializer.is_valid():
            store_instance = serializer.save()
            images = request.FILES.getlist('img')
            
            if images:
                image = images[0]  # Assuming only one logo is uploaded
                print(image)
                user_id = store_instance.user_id
                store_id = store_instance.id  # Assuming store id is generated after save
                
                # Upload image to S3
                s3 = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                                  aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)
                
                file_name = f"{user_id}/{store_id}/{image.name}"
                
                
                s3.upload_fileobj(image, settings.AWS_STORAGE_BUCKET_NAME, file_name)
                # Update logo URL in store instance
                logo_url = f"https://{settings.AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
                store_instance.logo = logo_url
                store_instance.save()
                
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['GET'])
def about(request):
    text=request.GET.get('text')
    generate=generate_about(text)
    return JsonResponse({'generate':generate})


@api_view(['POST'])
def update_template(request):
    if request.method == 'POST':
        user_id = request.data.get('user_id')
        store_id = request.data.get('store_id')
        catlog_id = request.data.get('catalog_id')

        if not all([user_id, store_id, catlog_id]):
            return Response({'error': 'Missing required parameters'}, status=400)

        content_type_id = 'productCatalogs'
        entries = client.entries({
                    'content_type': content_type_id,
                    'select': 'fields',  
                    'limit': 1000 
                })
        
        url = ""
        for entry in entries:
            id_value = entry.fields().get('templateid')   
            if id_value == catlog_id:
                url = entry.fields().get('catalog_template_url')
                break

        if not url:
            return Response({'error': 'Catalog template not found'}, status=404)

        store_data_list = get_store_by_user_id(user_id, store_id)
        product_data_list=get_product_by_user_id(user_id, store_id, catlog_id)

        if store_data_list:
            store_data = store_data_list[0]  # Assuming there's only one store matching the criteria
            m=html_update(url, store_data,product_data_list,user_id,store_id,catlog_id)
            return JsonResponse({'url': m})
        else:
            return Response({'error': 'Store not found'}, status=404)



def upload_to_s3(html_content, s3_file):
    s3 = boto3.client('s3',
                      aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                      aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                      region_name=settings.AWS_S3_REGION_NAME)
    bucket_name = settings.AWS_STORAGE_BUCKET_NAME

    try:
        s3.put_object(Body=html_content, Bucket=bucket_name, Key=s3_file)
        print(f"Upload successful: {s3_file}")
        s3_url = f"https://{bucket_name}.s3.amazonaws.com/{s3_file}"
        return s3_url
    except NoCredentialsError:
        print("Credentials not available.")
        return None

def html_update(url, store_data, product_data_list,user_id,store_id,catlog_id):
    response = requests.get(url)
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')

    # Update store logo
    logo_image = soup.find('img', class_='u-logo-image')
    if logo_image and store_data.get('logo'):
        logo_image['src'] = store_data['logo']

    # Update store name and about
    store_name = soup.find(class_='u-store-name')
    if store_name and store_data.get('name'):
        store_name.string = store_data['name']

    store_about = soup.find(class_='u-store-about')
    if store_about and store_data.get('about_store'):
        store_about.string = store_data['about_store']

    # Update address and contact details
    address_line_1 = soup.find(class_='u-address-line-1')
    if address_line_1 and store_data.get('store_address_line_1'):
        address_line_1.string = store_data['store_address_line_1']

    address_line_2 = soup.find(class_='u-address-line-2')
    if address_line_2 and store_data.get('store_address_line_2'):
        address_line_2.string = store_data['store_address_line_2']

    whatsapp_contact = soup.find(class_='u-whatsapp-contact')
    if whatsapp_contact and store_data.get('whatsapp_number'):
        whatsapp_contact.string = store_data['whatsapp_number']

    phone_contact = soup.find(class_='u-phone-contact')
    if phone_contact and store_data.get('phone_number'):
        phone_contact.string = store_data['phone_number']

    # Update hero image
    hero_img_data = next((p for p in product_data_list if p['image_type'] == 0), None)
    if hero_img_data:
        hero_img = soup.find('img', class_='u-hero-img')
        if hero_img:
            img_src = hero_img_data['product_image']
            hero_img['src'] = img_src
            hw = hero_img['data-image-width']
            hh = hero_img['data-image-height']
            print(hw, hh)

    about_img_data = next((p for p in product_data_list if p['image_type'] == 2), None)
    if about_img_data:
        about_img = soup.find('img', class_='u-about-img')
        if about_img:
            img_src = about_img_data['product_image']
            about_img['src'] = img_src
            hw = about_img['data-image-width']
            hh = about_img['data-image-height']
            print(hw, hh)

    # Update product images, names, descriptions, and prices
    for i, product_div in enumerate(soup.find_all(class_='u-list-item')):
        if i < len(product_data_list):
            product = product_data_list[i]
            if product['image_type']==1:
                img_tag = product_div.find('img', class_='u-list-item-img')
                if img_tag:
                    img_src = product['product_image']
                    img_tag['src'] = img_src

                name_tag = product_div.find(class_='u-list-item-name')
                if name_tag:
                    name_tag.string = product['product_name']

                desc_tag = product_div.find(class_='u-list-item-desc')
                if desc_tag:
                    desc_tag.string = product['product_description']

                price_tag = product_div.find(class_='u-list-item-price')
                if price_tag:
                    price_tag.string = f'{product["discounted_price"]}'



    html_content = str(soup.prettify())

    # Upload HTML content to S3
    s3_file = f"{user_id}/{store_id}/{catlog_id}.html"  # S3 path where you want to upload the file
    s3_url = upload_to_s3(html_content, s3_file)

    if s3_url:
        print(f"S3 URL: {s3_url}")
        return s3_url
    else:
        print("Failed to upload to S3.")
        return None



def get_store_by_user_id(user_id,store_id):
    try:
        stores = store.objects.filter(user_id=user_id,id=store_id)
        store_data_list = []
        for s in stores:
                store_data = {
                    'id': s.id,
                    'user_id': s.user_id,
                    'logo': s.logo,
                    'about_store': s.about_store,
                    'name': s.name,
                    'category': s.category,
                    'store_address_line_1':s.store_address_line_1,
                    'store_address_line_2':s.store_address_line_2,
                    'whatsapp_number':s.whatsapp_number,
                    'phone_number':s.phone_number
                }
                store_data_list.append(store_data)
        
        return store_data_list
    except store.DoesNotExist:
        return None

def get_product_by_user_id(user_id, store_id, catlog_id):
    try:
        product = products.objects.filter(user_id=user_id, store_id=store_id, catlog_id=catlog_id)
        product_data_list = []
        for s in product:
            product_image_src = s.ai_image if s.ai_image else s.product_image
            product_data = {
                'user_id': s.user_id,
                'store_id': s.store_id,
                'catalog_id': s.catalog_id,
                'product_name': s.product_name,
                'product_image': product_image_src,
                'product_description': s.product_description,
                'discounted_price': s.discounted_price,
                'image_type':s.image_type,
                'img_num': s.img_num
                    
            }
            product_data_list.append(product_data)
        
        return product_data_list
    except products.DoesNotExist:
        return None






@api_view(['POST'])
def generate_background(request):
    img_url=request.data.get('img_url')
    user_id = request.data.get('user_id')
    store_id = request.data.get('store_id')
    catlog_id = request.data.get('catalog_id')
    img_tag = request.data.get('image_type')
    img_keyword=request.data.get('img_keyword')
 #   b=query_image_caption("https://fridayyai.s3.ap-south-1.amazonaws.com/52k3eo1_2024-04-08T13_15_35.013Z_output_0.jpeg")
    desc = generate_text(img_keyword)

    content_type_id = 'productCatalogs'
    entries = client.entries({
                'content_type': content_type_id,
                'select': 'fields',  
                'limit': 1000 
            })
    
    url = ""
    for entry in entries:
        id_value = entry.fields().get('templateid')   
        if id_value == catlog_id:
            url = entry.fields().get('catalog_template_url')
            break


    img_tag=int(img_tag)
    dim=get_size(url,img_tag)
    print(dim, "dim")
    wid=dim[0]
    hgt=dim[1]
    s=(int(wid),int(hgt))
    temp_url=resize_and_pad_image(img_url,s,user_id,store_id)
    background=photai(temp_url,desc)
    return JsonResponse({'background':background})


def get_size(url,img_tag):
    response = requests.get(url)
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    hero_img = soup.find('img', class_='u-hero-img')
    about_img = soup.find('img', class_='u-about-img')
    k=[]
    if img_tag==0:
        hw=hero_img['data-image-width']  
        hh=hero_img['data-image-height']
        k.append(hw)
        k.append(hh)
        return k
        print(k)
    elif img_tag==2:
        hw=about_img['data-image-width']  
        hh=about_img['data-image-height']
        k.append(hw)
        k.append(hh)
        return k
    else:
        for i,product_div in enumerate(soup.find_all(class_='u-list-item')):
            img = product_div.find('img', class_='u-list-item-img')
            if img:
                iw=img['data-image-width']  
                ih=img['data-image-height']
                k.append(iw)
                k.append(ih)
                return k


def get_image_dimensions(img_link):
    response = requests.get(img_link)
    image_data = BytesIO(response.content)
    image = Image.open(image_data)
    return image.size  


def Image_extender(img_link, width, height):
    actual_width, actual_height = get_image_dimensions(img_link)
    width=int(width)
    height=int(height)


    scale_width = width / actual_width
    scale_height = height / actual_height

    scale_factor = min(scale_width, scale_height)

    url = 'https://prodapi.phot.ai/external/api/v2/user_activity/outpaint'
    headers = {
        'x-api-key': '661cd2e68bc855e650b13257_00082d7992f766ad0834_apyhitools',
        'Content-Type': 'application/json'
    }
    data = {
        "input_image_link": img_link,
        "aspect_ratio": "CUSTOM",
        "custom_params": {
            "canvas_h": height,
            "canvas_w": width,
            "center_x": 0,
            "center_y": 0,
            "scale": scale_factor,
            "rotation_angle": 0
        }
    }
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 200:
        print(response.json())
    else:
        print(f"Error: {response.status_code} - {response.text}")
    
    output = response.json()['data']['url']
    return output



def resize_and_pad_image(input_path,target_size,user_id,store_id,color=(0, 0, 0)):
    
    response = requests.get(input_path)
    img = Image.open(BytesIO(response.content))
    aspect_ratio = img.width / img.height
    
    if img.width > img.height:
        new_width = target_size[0]
        new_height = int(new_width / aspect_ratio)
    else:
        new_height = target_size[1]
        new_width = int(new_height * aspect_ratio)
    
    # Resize the image
    img = img.resize((new_width, new_height), Image.LANCZOS)
    
    new_img = Image.new("RGB", target_size, color)
    
    # Calculate position to paste the resized image to center it
    left = (target_size[0] - new_width) // 2
    top = (target_size[1] - new_height) // 2
    right = left + new_width
    bottom = top + new_height
    
    # Paste the resized image onto the new image
    new_img.paste(img, (left, top, right, bottom))

    image_buffer = BytesIO()
    # Save the new image to the BytesIO object
    new_img.save(image_buffer, format='JPEG')
    # Reset the buffer position to the start of the buffer
    image_buffer.seek(0)

    s3 = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)
    
    file_name = f"{user_id}/{store_id}/temp.jpeg"
    
    s3.upload_fileobj(image_buffer, settings.AWS_STORAGE_BUCKET_NAME, file_name)
    # Update logo URL in store instance
    temp_url = f"https://{settings.AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
    
    return temp_url


@api_view(['GET'])
def display_catlogs(request):
    # Fetch unique catlog_id values for the given user_id
    user_id = request.GET.get('user_id')
    unique_catalog_ids = products.objects.filter(user_id=user_id).values_list('catlog_id', flat=True).distinct()
    
    # Convert QuerySet to list
    unique_catalog_ids_list = list(unique_catalog_ids)

    content_type_id = 'productCatalogs'

    entries = client.entries({
        'content_type': content_type_id,
        'select': 'fields',  
        'limit': 1000 
    })

    links = []

    for i in unique_catalog_ids_list:
        for entry in entries:
            id=entry.fields().get('templateid') 
            if i==id:
                k = entry.fields().get('catalog_thumbnail')
                thumbnail = "https:" + str(k).split(' ')[-1].strip("'")[5:-2]
                links.append(thumbnail)
    return JsonResponse({'links':links})




 # Import the UpdatedHTML model

# all the backgrounds are different sizes, and when we paste images again with different sizes, few images looks big, goes out etc mam..
# say example

# photo room has same background sizes for each category - that show they are woring then they eare rezising and pasting, so image looks good for any upload images
# mam, now wach tempate has different sizes, then how to resize then and keep them ?
# we need to standize sizes
# or we need to save each image pixel sizes and based on that we need to resize image
# other thing we also might required coordinates - as few images like wooden board etc then image shd be at that coordinate
# one idea i have is - after selection we can send to that image extender but costs us one API



"""

def index(request):
    return render(request, 'index.html')


def home2(request):
    image_data = None
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            # Handle the uploaded image here
            image_data = request.FILES['image'].read()
    else:
        form = ImageForm()
    return render(request, 'home2.html', {'form': form, 'image_data': image_data})

# views.py

# views.py

from django.shortcuts import render
from .forms import ImageForm  # Import ImageForm
from .models import UploadedImage

def home1(request):
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            # Save the uploaded image to AWS S3 or any other storage
            uploaded_image = UploadedImage(image=request.FILES['image'])
            uploaded_image.save()

            # Get the public URL of the uploaded image
            image_url = uploaded_image.image.url
            cut_url = image_url.split("?")[0]
            print(cut_url)

            # Get the selected prompt from the form data
            prompt = request.POST.get('prompt')
            print(prompt)


            # Pass the URL and prompt to the template for display
            return render(request, 'home1.html', {'form': form, 'image_url': image_url, 'prompt': prompt})
    else:
        form = ImageForm()
    return render(request, 'home1.html', {'form': form})

client = Client('v4776asqgjtj', 'W0zMEEtQukZm7fBbawymdxQCiLkLGjYtBHTtqQVyrZw')
import json

@api_view(['GET'])
def get_template(request):

    if request.method == 'GET':
        category = request.GET.get('category', None)
        if category:
            content_type_id = 'productCatalogs'

            entries = client.entries({
                'content_type': content_type_id,
                'select': 'fields',  
                'limit': 1000 
            })

            category_templates = []

            for entry in entries:
                entry_category = entry.fields().get('category')
                url = entry.fields().get('catalog_template_url')
                title = entry.fields().get('title')
                k = entry.fields().get('catalog_thumbnail')
                thumbnail = "https:" + str(k).split(' ')[-1].strip("'")[5:-2]
                num = entry.fields().get('imgnumber')
                id=entry.fields().get('templateid')                
                if entry_category == category and url:
                    category_templates.append([title, url, thumbnail, num,id])


            # Optionally, you can render a template with the fetched data
            return JsonResponse({'category_templates': category_templates})
        else:
            return JsonResponse({'error': 'Category not provided'}, status=400)
    else:
        return JsonResponse({'error': 'Only GET method allowed'}, status=405)



from .models import UploadedImage  # Import your UploadedImage model if you have one

def show_template_details(request):
    template_id = request.GET.get('template_id', None)
    content_type_id = 'productCatalogs'
    entries = client.entries({
            'content_type': content_type_id,
            'select': 'fields',  
            'limit': 1000 
    })
    if request.method == 'GET':
        if template_id:
            template_details = []

            for entry in entries:
                url = entry.fields().get('catalog_template_url')
                title = entry.fields().get('title')
                k = entry.fields().get('catalog_thumbnail')
                thumbnail = "https:" + str(k).split(' ')[-1].strip("'")[5:-2]
                num = entry.fields().get('imgnumber')
                id=entry.fields().get('templateid')  
                if template_id == id:
                    template_details.append([title, url, thumbnail, num, id])

            # Render a template with the fetched template details
            return render(request, 'template_details.html', {'template_details': template_details})
        else:
            return JsonResponse({'error': 'Template ID not provided'}, status=400)
        
    elif request.method == 'POST':

        uploaded_images = request.FILES.getlist('images')
        template_id = request.GET.get('template_id', None)
        for entry in entries:
            id = entry.fields().get('templateid')
            if template_id == id:
                max_images_allowed = entry.fields().get('imgnumber')

        # Check if the number of uploaded images exceeds the allowed number
        if len(uploaded_images) > max_images_allowed:
            return HttpResponse('You can only upload up to {} images.'.format(max_images_allowed))
        image_urls = []
        detection=[]
        # Save the uploaded images to the database or storage
        for image in uploaded_images:
            # Example: save the image to a model named UploadedImage
            uploaded_image = UploadedImage(image=image)
            uploaded_image.save()
            image_urls.append(uploaded_image.image.url)
            k=query_image_caption(uploaded_image.image.url)
            detection.append(k[0]['generated_text'])

        image_detection_zip = zip(image_urls, detection)


        # After successful upload, render the template with updated AI description
        return render(request, 'display_image.html', {'image_detection_zip':image_detection_zip})
    else:
        return JsonResponse({'error': 'Only GET and POST methods allowed'}, status=405)
    
# views.py
from django.shortcuts import render
from urllib.parse import unquote

def add_description(request, img_id,img_url):
    # Your view logic here
    img_url = unquote(img_url)
    img_id=img_id
    k=query_image_caption(img_url)
    caption=k[0]['generated_text']
    description = None
    background=None
    if request.method == 'POST':
        action = request.POST.get('action')
        print("hi")
        if action == 'generate_description':
            print("hello")
            # Get caption from the form
            description = generate_desc(caption)
            print(description)
        if action=='generate_background':
            print("hi")
            desc = generate_text(caption)
            background=photai(img_url,desc)
            print(background)

        if action == 'save_product':
            product_name = request.POST.get('product_name')
            product_image = img_url
            ai_image = background
            product_price = request.POST.get('product_price')
            discounted_price = request.POST.get('discounted_price')
            product_description = description
            image_tag = img_id
            
            # Create and save a new Product instance
            product = Product.objects.create(
                product_name=product_name,
                product_image=product_image,
                ai_image=ai_image,
                product_price=product_price,
                discounted_price=discounted_price,
                product_description=product_description,
                image_tag=image_tag
            )

    return render(request, 'add_description.html', {'img_url': img_url,'img_id':img_id,'caption':caption,'description': description, 'background':background})


import requests
 
import time
# 661cd2e68bc855e650b13257_00082d7992f766ad0834_apyhitools
def photai(input_image_link,prompt):
    url = 'https://prodapi.phot.ai/external/api/v2/user_activity/background-generator'
    headers = {
    'x-api-key': '661cd2e68bc855e650b13257_00082d7992f766ad0834_apyhitools',
    'Content-Type': 'application/json'
    }
    data = {
    'file_name': 'FTDUV9D3_2024-03-30T07_16_44.558Z_output_3.jpeg', 
    'input_image_link': input_image_link,
    'prompt': prompt  
    }

    response = requests.post(url, headers=headers, json=data)

    if response.status_code == 200:
        print(response.json())
    else:
        print(f"Error: {response.status_code} - {response.text}")

    jsonfile=response.json()
    k=jsonfile['order_id']

    url = f"https://prodapi.phot.ai/external/api/v1/user_activity/order-status?order_id={k}"

    payload={}

    headers = {
    'x-api-key': '660139bcb75bd933bd2ee135_294557ccec6b82e637ad_apyhitools',
    'Content-Type': 'application/json'
    }
    
    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)
    temp=response.json()
    print(temp)
    order_status_code=temp['order_status_code']
    
    while(order_status_code!=200):
        url = f"https://prodapi.phot.ai/external/api/v1/user_activity/order-status?order_id={k}"
        payload={}

        headers = {
        'x-api-key': '660139bcb75bd933bd2ee135_294557ccec6b82e637ad_apyhitools',
        'Content-Type': 'application/json'
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        m=response.json()
        order_status_code=m['order_status_code']
        time.sleep(5)
    
    final=response.json()
    output=final['output_urls']
    
    return output

def resize_and_pad_image(input_path,target_size, color=(0, 0, 0)):
    
    response = requests.get(input_path)
    img = Image.open(BytesIO(response.content))
    aspect_ratio = img.width / img.height
    
    if img.width > img.height:
        new_width = target_size[0]
        new_height = int(new_width / aspect_ratio)
    else:
        new_height = target_size[1]
        new_width = int(new_height * aspect_ratio)
    
    # Resize the image
    img = img.resize((new_width, new_height), Image.LANCZOS)
    
    new_img = Image.new("RGB", target_size, color)
    
    # Calculate position to paste the resized image to center it
    left = (target_size[0] - new_width) // 2
    top = (target_size[1] - new_height) // 2
    right = left + new_width
    bottom = top + new_height
    
    # Paste the resized image onto the new image
    new_img.paste(img, (left, top, right, bottom))
    
    return new_img

import requests

# Inference API for img-to-text (captioning):
API_URL = "https://api-inference.huggingface.co/models/Salesforce/blip-image-captioning-large"
headers = {"Authorization": "Bearer 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"}

def query_image_caption(image):
    response = requests.post(API_URL, headers=headers, data=image)
    return response.json()


from django.shortcuts import render
from django.http import HttpResponse
from .models import UploadedImage

def upload_images(request):
    if request.method == 'POST':
        template_url = request.POST.get('template_url')
        title = request.POST.get('title')
        number = request.POST.get('number')
        
        # Get the uploaded images from the request
        uploaded_images = request.FILES.getlist('images')
        
        # Check if the number of uploaded images exceeds the allowed number
        if len(uploaded_images) > int(number):
            return HttpResponse('You can only upload up to {} images.'.format(number))
        
        # Save the uploaded images to the database or storage
        for image in uploaded_images:
            # Example: save the image to a model named UploadedImage
            uploaded_image = UploadedImage(image=image)
            uploaded_image.save()
        
        # Redirect the user to a success page or another URL
        return HttpResponse('Images uploaded successfully!')
    
    else:
        return HttpResponse('Method not allowed')
    

from openai import OpenAI
import json

api_key = config('API_KEY')
cl = OpenAI(api_key=api_key)

def generate_text(text: str):
    response = cl.chat.completions.create(
        model="gpt-3.5-turbo", #"gpt-3.5-turbo-0125", #"gpt-3.5-turbo",
        response_format={ "type": "json_object" },
        messages=[
            {
                "role": "system",
                "content": 'Act as an expert social media marketer for an e-commerce brand. '
                        'I will send you the name of the product. Please send 1 background idea, '
                        'that would be relevant and would make the product images more visually attractive '
                        'for product catalogs, Instagram, and other social media networks. '
                        'Please send 1-line ideas. (**Do not add the product in the one-line idea.**) '
                        'Just write only the idea. Please send the result in the following JSON format: '
                        '{"idea": "<your generated idea here>"}'
            },
            {
                "role": "user",
                "content": f"Product: {text}"
            },
        ],
        temperature=1,
        max_tokens=1024,
        )
    try:
        generated_text = response.choices[0].message.content
        data = json.loads(generated_text) # Load the JSON string into a dictionary
        idea = data["idea"] # Extract the idea directly return idea
        print(idea)
        return idea
    except Exception as e:
        print(f"An error occurred, probably openai being smart again : {e}")

def generate_desc(text: str):
    response = cl.chat.completions.create(
        model="gpt-3.5-turbo", #"gpt-3.5-turbo-0125", #"gpt-3.5-turbo",
        response_format={ "type": "json_object" },
        messages=[
            {
                "role": "system",
                "content": 'Act as an expert social media marketer for an e-commerce brand.'
                        'I will send you a few keywords that describes the product'
                        'Can you create a 2 - 3 line product description emphasizing the key features, benefits, and unique selling points.'
                        'Please create a 2 -3 line description.'
                        'Send the response in the following JSON format - { description: <Description>}'
            },
            {
                "role": "user",
                "content": f"Product: {text}"
            },
        ],
        temperature=1,
        max_tokens=1024,
        )
    try:
        generated_text = response.choices[0].message.content
        data = json.loads(generated_text) # Load the JSON string into a dictionary
        idea = data["description"] # Extract the idea directly return idea
        print(idea)
        return idea
    except Exception as e:
        print(f"An error occurred, probably openai being smart again : {e}")

"""
