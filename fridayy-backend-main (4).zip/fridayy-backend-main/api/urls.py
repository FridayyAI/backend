from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    
    
    #Auth
    path("login/",views.login, name="login"),
    path("logout/",views.logout, name="logout"),
    path("register/",views.register, name="register"),
    path("user/",views.get_user, name="user"),
    path("google_login/",views.google_login, name="google_login"),
    path("test_token/",views.test_token, name="test_token"),
    #store
    # path("store/", views.StoreCreate.as_view(), name="store"),
    # path("store/update/<int:pk>/", views.StoreUpdate.as_view(), name="store"),
    # path("store/delete/<int:pk>/", views.StoreDelete.as_view(), name="delete_store"),

    path('get_template/', views.get_template, name='get_templates'),
    path('product/keyword/', views.object_detection, name='object_detection'),
    path('product/description/', views.description, name='description'),
    path('product/background/', views.generate_background, name='generate_background'),
    path('product/create/', views.create_product, name='create_product'),
    path('images/upload/',views.upload_img,name="upload_image"),
    path('images/upload_hero/',views.upload_img_hero,name="upload_img_hero"),
    path('images/upload_about/',views.upload_img_about,name="upload_img_about"),
    path('users/store/', views.create_store, name='create_store'),
    path('user/about/', views.about, name='about'),
    path('update_template/', views.update_template, name='update_template'),
    path('user/display_catlogs/', views.display_catlogs, name='display_catlogs'),

    
    
    # path("user/register/", CreateUserView.as_view(), name="register"),
    # path("token/", TokenObtainPairView.as_view(), name="get_token"),
    # path("token/refresh/", TokenRefreshView.as_view(), name="refresh"),
]
