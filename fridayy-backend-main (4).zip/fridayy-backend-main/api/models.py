from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.urls import reverse
from django.utils.translation import gettext_lazy as _


class FridayUserManager(BaseUserManager):
    def create_user(self, email, first_name, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, first_name=first_name, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, first_name, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')

        return self.create_user(email, first_name, password, **extra_fields)


class Category(models.Model):
    category = models.CharField(max_length=100)
    def __str__(self):
        return self.category

class UploadedImage(models.Model):
    image = models.ImageField(upload_to='images/')
    def __str__(self):
        return self.image.url
    
class FridayUser(AbstractBaseUser):
    
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100, blank=True, null=True)
    phone_no = models.CharField(max_length=20, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    is_google_login = models.BooleanField(default=False)
    last_login = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name']
    
    objects = FridayUserManager()
    def __str__(self):
        return f"{self.first_name} {self.last_name if self.last_name else ''}"

class store(models.Model):
    id = models.AutoField(primary_key=True)
    user_id = models.CharField(max_length=50)
    logo = models.CharField(max_length=255,null=True, blank=True)
    about_store = models.TextField()
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=255)
    store_address_line_1=models.CharField(max_length=255)
    store_address_line_2=models.CharField(max_length=255)
    whatsapp_number=models.CharField(max_length=20,null=True)
    phone_number=models.CharField(max_length=20)
    def __str__(self):
        return self.store_name
    
    
class UpdatedHTML(models.Model):
    html_content = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Updated HTML {self.id}"

class Catelog(models.Model):
    catelog_name = models.CharField(max_length=100)
    catelog_hero_image = models.CharField(max_length=100)
    catelog_hero_text = models.TextField()
    catelog_product_order = models.JSONField()
    store_id = models.ForeignKey(store,on_delete=models.CASCADE, related_name="catelog")
    user_id = models.ForeignKey(FridayUser,on_delete=models.CASCADE, related_name="catelog")
    def __str__(self) -> str:
        return self.catelog_name
    
class products(models.Model):
    user_id = models.CharField(max_length=20)
    store_id = models.CharField(max_length=20)
    catalog_id = models.CharField(max_length=20)
    product_name = models.CharField(max_length=255)
    product_image = models.URLField()
    ai_image = models.URLField(null=True, blank=True)
    product_price = models.DecimalField(max_digits=10, decimal_places=2)
    discounted_price = models.DecimalField(max_digits=10, decimal_places=2)
    product_description = models.CharField(max_length=500)
    image_type = models.IntegerField()
    img_order = models.IntegerField()
    def __str__(self) -> str:
        return self.product_name
    
