Friday AI Backend:
====================

Here is the setup tutorial

create a virtual environment nameed ".venv" and activate it

```
python3 -m venv .venv
```
for linux users
```
source ./venv/bin/activate 
```
for windows users
```
.\.venv\Scripts\activate
```

Then install Python Poetry Package mangager

```
pip install poetry

poetry install

```

configure the database according to your systems configuration in the ```Fridyy/settings.py``` file

run the following commands to make the migrations

```
python manage.py makemigrations
python manage.py migrate
```

finally run the django server by running 
```
python manage.py runserver
```

