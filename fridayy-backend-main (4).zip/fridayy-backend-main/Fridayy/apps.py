from django.apps import AppConfig
class FridayyConfig(AppConfig):
    name = 'Fridayy'
    verbose_name = 'A Much Better Name'